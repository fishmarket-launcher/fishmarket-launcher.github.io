FishMarket for Linux (first build: untested on real Linux)
==========================================================

This build has not run on a real Linux computer yet. Please report what
works and what does not.

Start
  Run ./fishmarket-x86_64 from this folder (fmk must stay next to it).
  If double-clicking does nothing, open a terminal here and run:
    chmod +x fishmarket-x86_64 fmk
    ./fishmarket-x86_64
  Some desktops mount USB drives so programs on them cannot run. Then copy
  this folder into your home folder and start it from there.

What it needs
  A desktop with Wayland or X11 and OpenGL. To run Windows games it uses
  umu-run with Proton (umu downloads Proton and the Steam runtime, about
  1.5 GB, the first time) or a Wine you have installed. Check this PC with:
    ./fmk doctor

Where things live
  Your library, settings and captured saves: ~/.local/share/fishmarket
  (a FishMarket drive keeps its own library on the drive).

Command line
  ./fmk add <game.exe>, ./fmk scan <dir> --add, ./fmk ls, ./fmk run <game>,
  ./fmk --help.
