FishMarket for Windows
======================

Start FishMarket-Windows.exe. Nothing is installed: your library, settings and
captured saves live in %LOCALAPPDATA%\FishMarket, and this folder can be
anywhere.

Add games
  Type /add in the bar at the bottom to pick a game's .exe, or /scan to
  pick a folder and choose the games found in it.

Cover art
  Click "Connect SteamGridDB" on the library banner. Open the API page,
  log in with Steam and copy your key, then come back: FishMarket picks the
  key up from the clipboard, checks it and fetches every missing cover.

Play
  Enter (or A on a controller) plays the focused game. Esc / B goes back.
  The toggle at the top right switches Big Picture and Console layouts.
  F11 is full screen. Settings (the gear) has themes, sound and music
  (Add music... takes your own MP3, FLAC, WAV, M4A or Ogg), and controller
  options.

Controller
  A play/select, B back, X details, Y favorite, LB/RB tabs, Menu settings,
  View layout, Guide brings FishMarket to the front. A on a text field
  opens the on-screen keyboard.

Take your games to other PCs
  fmk market init E:\ --drive --name "Game Drive"
  fmk --market E:\FishMarket add E:\Games\Some Game\Game.exe
  Then start FishMarket-Windows.exe from the drive on any PC; saves are restored
  before each launch and captured after it.

Command line
  fmk.exe does everything from a terminal: fmk add, fmk scan <dir> --add,
  fmk ls, fmk run <game>, fmk sgdb key <KEY>, fmk --help.

Licenses of bundled fonts, themes and sounds are in licenses\.
The interface is built with Slint (https://slint.dev).
