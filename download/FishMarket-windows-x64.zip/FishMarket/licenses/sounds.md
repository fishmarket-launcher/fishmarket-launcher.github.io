# Sound asset licenses

## Interface effects (original)

`move`, `key`, `select`, `back`, `tab`, `toggle`, `open`, `error`, `notify` and `launch` are synthesized from scratch by `tools/sfx/synth.py` in this repository (sines, filtered noise and a generated room reverb; no samples). They are part of FishMarket and under its license. Rebuild with:

```sh
python tools/sfx/synth.py crates/fishmarket/assets/sounds
```

Their character (soft attacks, warm low-mid register, short airy tails) was tuned by comparing spectra and envelopes against console home-screen interface sounds. No console sounds, recordings or samples are included or derived from.

## Ambient tracks

| File | Source page | Original file | Author | License | Processing |
|---|---|---|---|---|---|
| ambient-calm.ogg | https://opengameart.org/content/ambient-relaxing-loop | `Ambient-Loop-isaiah658.wav` | isaiah658 | CC0 1.0 | 48 kHz stereo, seamless loop ×5 (≈122 s), −19 LUFS, 1.5 s fade-in / 2 s fade-out, limiter −3 dBFS, libvorbis q4 |
| ambient-deep.ogg | https://opengameart.org/content/underwater-ambient-pad | `Underwater-Ambient-Pad-isaiah658.wav` | isaiah658 | CC0 1.0 | 48 kHz stereo, seamless loop ×6 (≈100 s), −19 LUFS, 1.5 s fade-in / 2 s fade-out, limiter −3 dBFS, libvorbis q4 |

CC0 1.0: https://creativecommons.org/publicdomain/zero/1.0/
